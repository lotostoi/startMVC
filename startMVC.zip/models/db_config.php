<?php
const SERVNAME = 'localhost';
const USERNAME = 'root';
const PASSWORD = '';
const DBNAME = 'shop_e';
const CART = 'cart';
const SHOPE = 'shope';
const USERS = 'users';
const COTALOG = 'cotalog';
const NEW_USER = 'new_user';
const ORDERS = 'orders';
const DB_CHAR = 'utf8';
const SESSION = 'session';
