<?php
const SERVNAME = 'localhost';
const USERNAME = 'root';
const PASSWORD = '';
const DBNAME = 'shop_e';
const CART = 'cart';
const SHOPE = 'shope';
const USERS = 'users';
const COTALOG = 'cotalog';
const NEW_USER = 'new_user';
const ORDERS = 'orders';
const DB_CHAR = 'utf8';
const SESSION = 'session';
const REVIEWS= 'reviews';


// for server
/* const SERVNAME = 'localhost';
const USERNAME = 'u1048424';
const PASSWORD = 'EUDaawww1';
const DBNAME = 'u1048424_shop_e';
const CART = 'cart';
const SHOPE = 'shope';
const USERS = 'users';
const COTALOG = 'cotalog';
const NEW_USER = 'new_user';
const ORDERS = 'orders';
const DB_CHAR = 'utf8';
const SESSION = 'session'; */
