<?php

include_once 'models/db_config.php';
// настроен и для моего проекта 
require_once './vendor/autoload.php';


new \controller\Router();



