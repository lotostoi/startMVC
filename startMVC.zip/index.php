<?php
include_once 'models/config/db_config.php';

// настроен и для моего проекта 
require_once './vendor/autoload.php';


new \controller\Router();



