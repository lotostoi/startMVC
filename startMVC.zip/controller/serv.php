<?php 
require_once './../vendor/autoload.php';
require_once "./../models/config/db_config.php";


new \models\server\M_server();